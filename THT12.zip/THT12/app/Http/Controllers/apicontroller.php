<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use GuzzleHttp\Client;
class apicontroller extends Controller
{
    //
    public function index()
    {
        $client = new Client();
        $response = $client::get('GET https://newsapi.org/v2/everything?q=bitcoin&apiKey=774321a7642b4dd381dc58e3e8169d55');
        $data = json_decode($response->getBody(),true);

        return view('bitcoin',['bitcoin'=>$data['articles']]);
    }
}
