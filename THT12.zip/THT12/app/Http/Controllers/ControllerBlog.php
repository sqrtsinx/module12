<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class ControllerBlog extends Controller
{
    //
    public function index()
    {
        $blogs = User::latest()->paginate(10);
        return[
            "status"=>1,
            "data"=>$blogs
        ];
    }

    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        $request->validate([
            'title'=>'required',
            'body'=>'required'
        ]);

        $blog = User::create($request->all());
        return[
            "status"=>1,
            "data"=>$blog
        ];
    }

    public function show(User $user)
    {
        return [
            "status"=>1,
            "data"=>$user
        ];
    }

    public function edit(User $user)
    {

    }

    public function update(Request $request, User $user)
    {
        $request->validate([
            'title'=>'required',
            'body'=>'required'
        ]);

        $user->update($request->all());

        return[
            "status"=>1,
            "data"=>$user,
            "msg"=>"User updated successfully"
        ];
    }

    public function destroy(User $user)
    {
        $user->delete();
        return [
            "status" =>1,
            "data" => $blog,
            "msg" => "User deleted successfully"
        ];
    }
}
